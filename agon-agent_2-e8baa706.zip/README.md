# HeroBot 26.2 — AI Companion Bot (Minecraft Java 26.2, Fabric)

HeroBot spawns a controllable, player-like AI companion that follows, fights, protects,
and survives alongside its owner. Built for **Minecraft Java Edition 26.2** on **Fabric**.

## Verified environment (grounded against Fabric/Mojang metadata, Nov 2026)
- **Minecraft:** 26.2 (protocol 776, data 4903) — requires **Java 25**
- **Fabric Loader:** 0.20.1
- **Fabric API:** 0.159.0+26.2
- **Loom:** 1.19.4 · **Gradle:** 9.8.2
- **Mappings:** official Mojang mappings (Yarn is not published for calendar versions;
  Loom 1.19 applies Mojang mappings by default). Note: `ResourceLocation` is named
  `net.minecraft.resources.Identifier` in 26.2.

## Build
```bash
export JAVA_HOME=/path/to/jdk-25
./gradlew build
```
The mod JAR is produced at `build/libs/herobot-26.2.0.jar`.

## Install
1. Install the Fabric Loader (0.20.1+) for Minecraft 26.2.
2. Put **Fabric API** (0.159.0+26.2) and **herobot-26.2.0.jar** in your `mods/` folder.
3. Launch with the Java 25 runtime bundled by the official launcher.

## Commands
`/herobot spawn | remove | follow | stay | come | attack | defend | protect |
mine <block> | collect | inventory | equip | status | teleport | help`

## Architecture
`herobot` (init) · `herobot.entity` · `herobot.ai` · `herobot.navigation` ·
`herobot.combat` · `herobot.commands` · `herobot.inventory` · `herobot.config` ·
`herobot.network` · `herobot.mixin` · `herobot.client`

The bot extends `TamableAnimal`, giving it owner tracking, sitting, and vanilla
owner-teleport recovery. Vanilla AI `Goal`s provide robust A* ground navigation,
obstacle avoidance and stair climbing; combat, survival and behaviour-mode logic are
layered on top. A `Mob` mixin lets hostile mobs recognise the bot as a target.

## Build/compile status
Compiled and packaged successfully against the real Minecraft 26.2 + Fabric toolchain
(`./gradlew build` → `BUILD SUCCESSFUL`, remapped JAR produced). In-game runtime
behaviour was not play-tested (no Minecraft client/server was launched in this
environment).
