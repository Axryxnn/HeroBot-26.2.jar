package com.herobot.client;

import com.herobot.HeroBot;
import com.herobot.entity.HeroBotEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

/**
 * Renders the HeroBot with a player-like humanoid model and a custom texture.
 */
public class HeroBotRenderer
		extends HumanoidMobRenderer<HeroBotEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
	private static final Identifier TEXTURE =
			Identifier.fromNamespaceAndPath(HeroBot.MOD_ID, "textures/entity/herobot.png");

	public HeroBotRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<>(context.getModelSet().bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
	}

	@Override
	public HumanoidRenderState createRenderState() {
		return new HumanoidRenderState();
	}

	@Override
	public Identifier getTextureLocation(HumanoidRenderState state) {
		return TEXTURE;
	}
}
