package com.herobot.entity;

import com.herobot.ai.BehaviorMode;
import com.herobot.combat.CombatManager;
import com.herobot.config.ConfigManager;
import com.herobot.config.HeroBotConfig;
import com.herobot.inventory.EquipmentManager;
import com.herobot.navigation.NavigationHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * The HeroBot companion entity. Built on top of {@link TamableAnimal} so it inherits owner tracking,
 * sitting, and the vanilla "teleport to owner" helpers, while vanilla AI {@code Goal}s provide the
 * robust A*-based ground navigation, obstacle avoidance and stair climbing. Combat, survival and
 * behaviour-mode logic are layered on top.
 */
public class HeroBotEntity extends TamableAnimal implements RangedAttackMob {
	private static final EntityDataAccessor<Byte> DATA_MODE =
			SynchedEntityData.defineId(HeroBotEntity.class, EntityDataSerializers.BYTE);

	@Nullable
	private Vec3 stayAnchor;
	private int tickCounter;

	public HeroBotEntity(EntityType<? extends TamableAnimal> type, Level level) {
		super(type, level);
		setPersistenceRequired();
		setCanPickUpLoot(true);
	}

	public static AttributeSupplier.Builder createAttributes() {
		HeroBotConfig cfg = ConfigManager.get();
		return TamableAnimal.createMobAttributes()
				.add(Attributes.MAX_HEALTH, cfg.maxHealth)
				.add(Attributes.MOVEMENT_SPEED, cfg.movementSpeed)
				.add(Attributes.ATTACK_DAMAGE, cfg.attackDamage)
				.add(Attributes.ATTACK_KNOCKBACK, 1.0D)
				.add(Attributes.FOLLOW_RANGE, 32.0D)
				.add(Attributes.ARMOR, 6.0D)
				.add(Attributes.STEP_HEIGHT, 1.0D);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_MODE, BehaviorMode.FOLLOW.toByte());
	}

	@Override
	protected void registerGoals() {
		HeroBotConfig cfg = ConfigManager.get();
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
		goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
		goalSelector.addGoal(4, new FollowOwnerGoal(this,
				1.1D, (float) cfg.followStartDistance, (float) cfg.followStopDistance));
		goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9D));
		goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
		goalSelector.addGoal(8, new RandomLookAroundGoal(this));

		targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
		targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		targetSelector.addGoal(3, new HurtByTargetGoal(this));
		targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, true));
	}

	// ---- behaviour mode ----

	public BehaviorMode getBehaviorMode() {
		return BehaviorMode.fromByte(this.entityData.get(DATA_MODE));
	}

	public void setBehaviorMode(BehaviorMode mode) {
		this.entityData.set(DATA_MODE, mode.toByte());
		switch (mode) {
			case STAY -> {
				setOrderedToSit(true);
				this.stayAnchor = position();
				getNavigation().stop();
			}
			case FOLLOW, COME -> {
				setOrderedToSit(false);
				this.stayAnchor = null;
			}
			default -> setOrderedToSit(false);
		}
	}

	// ---- per-tick survival / combat upkeep ----

	@Override
	public void customServerAiStep(ServerLevel level) {
		super.customServerAiStep(level);
		tickCounter++;
		if (tickCounter % 20 != 0) {
			return;
		}
		HeroBotConfig cfg = ConfigManager.get();
		float healthFraction = getHealth() / getMaxHealth();

		// Retreat & stop fighting when badly hurt.
		if (healthFraction <= cfg.retreatHealthFraction && getTarget() != null) {
			setTarget(null);
			NavigationHelper.retreatToOwner(this);
		}

		// Eat held food when hurt.
		if (healthFraction <= cfg.eatHealthFraction) {
			EquipmentManager.tryEatHeldFood(this, level);
		}

		// Pick the best weapon for the current situation.
		CombatManager.selectEquipment(this);

		// Keep "stay" bots anchored and rescue stuck bots.
		if (getBehaviorMode() == BehaviorMode.STAY && stayAnchor != null) {
			if (position().distanceToSqr(stayAnchor) > 9.0D) {
				getNavigation().moveTo(stayAnchor.x, stayAnchor.y, stayAnchor.z, 1.0D);
			}
		} else {
			NavigationHelper.rescueIfStuck(this);
		}
	}

	@Override
	public void performRangedAttack(LivingEntity target, float power) {
		CombatManager.performRangedAttack(this, target, power);
	}

	@Override
	public boolean isFood(net.minecraft.world.item.ItemStack stack) {
		return false;
	}

	@Nullable
	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
		return null; // HeroBots are summoned, never bred.
	}

	@Override
	public boolean canBeLeashed() {
		return true;
	}

	public Component ownerName() {
		LivingEntity owner = getOwner();
		return owner != null ? owner.getName() : Component.literal("<none>");
	}
}
