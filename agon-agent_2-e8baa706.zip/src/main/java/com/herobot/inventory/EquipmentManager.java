package com.herobot.inventory;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Handles the bot's armour/tool loadout and food consumption.
 */
public final class EquipmentManager {
	private EquipmentManager() {
	}

	/** Give the bot a full starter kit of iron armour, a sword, a shield and some food. */
	public static void equipStarterKit(HeroBotEntity bot) {
		bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
		bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
		bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
		bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
		bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
		bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
	}

	/**
	 * If the bot is holding edible food and is hurt, heal it and consume one item. Returns true if
	 * food was eaten.
	 */
	public static boolean tryEatHeldFood(HeroBotEntity bot, ServerLevel level) {
		ItemStack main = bot.getMainHandItem();
		if (main.get(net.minecraft.core.component.DataComponents.FOOD) == null) {
			return false;
		}
		if (bot.getHealth() >= bot.getMaxHealth()) {
			return false;
		}
		bot.heal(6.0F);
		main.shrink(1);
		return true;
	}
}
