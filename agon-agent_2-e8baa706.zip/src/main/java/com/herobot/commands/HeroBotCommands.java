package com.herobot.commands;

import com.herobot.ai.BehaviorMode;
import com.herobot.config.ConfigManager;
import com.herobot.entity.HeroBotEntities;
import com.herobot.entity.HeroBotEntity;
import com.herobot.inventory.EquipmentManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Registers and implements the full {@code /herobot ...} command tree with argument validation and
 * helpful error messages.
 */
public final class HeroBotCommands {
	private HeroBotCommands() {
	}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		dispatcher.register(Commands.literal("herobot")
				.then(Commands.literal("spawn").executes(HeroBotCommands::spawn))
				.then(Commands.literal("remove").executes(HeroBotCommands::remove))
				.then(Commands.literal("follow").executes(ctx -> setMode(ctx, BehaviorMode.FOLLOW)))
				.then(Commands.literal("stay").executes(ctx -> setMode(ctx, BehaviorMode.STAY)))
				.then(Commands.literal("come").executes(HeroBotCommands::come))
				.then(Commands.literal("attack").executes(ctx -> setMode(ctx, BehaviorMode.ATTACK)))
				.then(Commands.literal("defend").executes(ctx -> setMode(ctx, BehaviorMode.DEFEND)))
				.then(Commands.literal("protect").executes(ctx -> setMode(ctx, BehaviorMode.PROTECT)))
				.then(Commands.literal("mine")
						.then(Commands.argument("block", StringArgumentType.word())
								.executes(HeroBotCommands::mine)))
				.then(Commands.literal("collect").executes(ctx -> setMode(ctx, BehaviorMode.COLLECT)))
				.then(Commands.literal("inventory").executes(HeroBotCommands::inventory))
				.then(Commands.literal("equip").executes(HeroBotCommands::equip))
				.then(Commands.literal("status").executes(HeroBotCommands::status))
				.then(Commands.literal("teleport").executes(HeroBotCommands::teleport))
				.then(Commands.literal("help").executes(HeroBotCommands::help))
				.executes(HeroBotCommands::help));
	}

	// ---- helpers ----

	private static HeroBotEntity findBot(ServerPlayer player) {
		ServerLevel level = (ServerLevel) player.level();
		AABB box = player.getBoundingBox().inflate(64.0D);
		List<HeroBotEntity> bots = level.getEntitiesOfClass(HeroBotEntity.class, box,
				bot -> bot.isOwnedBy(player) && bot.isAlive());
		HeroBotEntity nearest = null;
		double best = Double.MAX_VALUE;
		for (HeroBotEntity bot : bots) {
			double d = bot.distanceToSqr(player);
			if (d < best) {
				best = d;
				nearest = bot;
			}
		}
		return nearest;
	}

	private static void feedback(CommandSourceStack src, String msg) {
		src.sendSuccess(() -> Component.literal("\u00A7b[HeroBot] \u00A7f" + msg), false);
	}

	// ---- command bodies ----

	private static int spawn(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		ServerLevel level = (ServerLevel) player.level();
		HeroBotEntity bot = HeroBotEntities.HEROBOT.create(level, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("Failed to create HeroBot entity."));
			return 0;
		}
		bot.snapTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), 0.0F);
		bot.setTame(true, true);
		bot.setOwner(player);
		bot.setBehaviorMode(BehaviorMode.FOLLOW);
		if (ConfigManager.get().showNameTag) {
			bot.setCustomName(Component.literal(player.getName().getString() + "'s HeroBot"));
			bot.setCustomNameVisible(true);
		}
		if (ConfigManager.get().equipOnSpawn) {
			EquipmentManager.equipStarterKit(bot);
		}
		level.addFreshEntity(bot);
		feedback(ctx.getSource(), "HeroBot spawned and now following you.");
		return 1;
	}

	private static int remove(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby (within 64 blocks)."));
			return 0;
		}
		bot.discard();
		feedback(ctx.getSource(), "HeroBot removed.");
		return 1;
	}

	private static int setMode(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx, BehaviorMode mode) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby. Use /herobot spawn first."));
			return 0;
		}
		bot.setBehaviorMode(mode);
		feedback(ctx.getSource(), "HeroBot behaviour set to " + mode.id() + ".");
		return 1;
	}

	private static int come(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		bot.setBehaviorMode(BehaviorMode.FOLLOW);
		bot.getNavigation().moveTo(player.getX(), player.getY(), player.getZ(), 1.3D);
		feedback(ctx.getSource(), "HeroBot is coming to you.");
		return 1;
	}

	private static int mine(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		String block = StringArgumentType.getString(ctx, "block");
		bot.setBehaviorMode(BehaviorMode.MINE);
		feedback(ctx.getSource(), "HeroBot will mine nearby '" + block + "' blocks.");
		return 1;
	}

	private static int inventory(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		StringBuilder sb = new StringBuilder("Equipment -> ");
		for (EquipmentSlot slot : EquipmentSlot.values()) {
			ItemStack stack = bot.getItemBySlot(slot);
			if (!stack.isEmpty()) {
				sb.append(slot.getName()).append('=').append(stack.getHoverName().getString()).append(' ');
			}
		}
		feedback(ctx.getSource(), sb.toString());
		return 1;
	}

	private static int equip(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		EquipmentManager.equipStarterKit(bot);
		feedback(ctx.getSource(), "HeroBot re-equipped with a full iron loadout.");
		return 1;
	}

	private static int status(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		String msg = String.format("Mode=%s Health=%.1f/%.1f Target=%s",
				bot.getBehaviorMode().id(), bot.getHealth(), bot.getMaxHealth(),
				bot.getTarget() == null ? "none" : bot.getTarget().getName().getString());
		feedback(ctx.getSource(), msg);
		return 1;
	}

	private static int teleport(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer player = ctx.getSource().getPlayerOrException();
		HeroBotEntity bot = findBot(player);
		if (bot == null) {
			ctx.getSource().sendFailure(Component.literal("No HeroBot of yours found nearby."));
			return 0;
		}
		bot.teleportTo(player.getX(), player.getY(), player.getZ());
		feedback(ctx.getSource(), "HeroBot teleported to you.");
		return 1;
	}

	private static int help(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx) {
		String[] lines = {
				"/herobot spawn - summon your bot",
				"/herobot remove - despawn your bot",
				"/herobot follow | stay | come - movement",
				"/herobot attack | defend | protect - combat modes",
				"/herobot mine <block> | collect - survival",
				"/herobot inventory | equip - gear",
				"/herobot status | teleport - utility",
		};
		feedback(ctx.getSource(), "HeroBot commands:");
		for (String line : lines) {
			ctx.getSource().sendSuccess(() -> Component.literal("\u00A77 " + line), false);
		}
		return 1;
	}
}
