package com.herobot.ai;

/**
 * The high-level behaviour state a {@code HeroBotEntity} can be in. The active mode is stored as a
 * synced byte on the entity so the client always knows the bot's current intent.
 */
public enum BehaviorMode {
	FOLLOW("follow"),
	STAY("stay"),
	COME("come"),
	ATTACK("attack"),
	DEFEND("defend"),
	PROTECT("protect"),
	MINE("mine"),
	COLLECT("collect"),
	IDLE("idle");

	private final String id;

	BehaviorMode(String id) {
		this.id = id;
	}

	public String id() {
		return id;
	}

	public byte toByte() {
		return (byte) ordinal();
	}

	public static BehaviorMode fromByte(byte b) {
		BehaviorMode[] values = values();
		if (b < 0 || b >= values.length) {
			return FOLLOW;
		}
		return values[b];
	}

	/** True when the bot should actively seek out and engage hostile mobs. */
	public boolean isAggressive() {
		return this == ATTACK || this == DEFEND || this == PROTECT;
	}
}
