package com.herobot.mixin;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lets vanilla hostile mobs recognise a {@link HeroBotEntity} as a valid combat target, so the bot
 * genuinely draws aggro while protecting its owner. Injected at the tail of {@code Mob.registerGoals}.
 */
@Mixin(Mob.class)
public abstract class MobTargetMixin {
	@Shadow
	protected GoalSelector targetSelector;

	@Inject(method = "registerGoals", at = @At("TAIL"), require = 0)
	private void herobot$targetHeroBots(CallbackInfo ci) {
		Mob self = (Mob) (Object) this;
		if (self instanceof Monster && !(self instanceof HeroBotEntity)) {
			this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(self, HeroBotEntity.class, true));
		}
	}
}
