package com.herobot.config;

/**
 * Plain data holder serialised to/from {@code config/herobot.json} via Gson.
 * Every field maps directly to a tunable the bot reads at runtime.
 */
public class HeroBotConfig {
	/** Max health the bot spawns with (also its attribute MAX_HEALTH). */
	public double maxHealth = 40.0D;
	/** Base movement speed attribute. */
	public double movementSpeed = 0.32D;
	/** Melee attack damage attribute. */
	public double attackDamage = 6.0D;
	/** How far (blocks) the bot may wander before it is forced back toward the owner. */
	public double followStartDistance = 8.0D;
	/** Distance at which the bot stops approaching the owner while following. */
	public double followStopDistance = 2.0D;
	/** Health fraction (0-1) below which the bot retreats and stops attacking. */
	public double retreatHealthFraction = 0.25D;
	/** Health fraction (0-1) below which the bot eats food from its hand if it has any. */
	public double eatHealthFraction = 0.6D;
	/** AI difficulty 1-3; scales aggression range and reaction speed. */
	public int aiDifficulty = 2;
	/** Whether the bot automatically picks up nearby dropped items. */
	public boolean autoCollectItems = true;
	/** Whether only the owner may issue commands to the bot. */
	public boolean ownerOnlyCommands = true;
	/** Equip the bot with starter armour + weapon on spawn. */
	public boolean equipOnSpawn = true;
	/** Show the bot's name tag above its head. */
	public boolean showNameTag = true;
}
